import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Linkedin } from "lucide-react";

export default function Home() {
  return (
    <main className="p-6 max-w-5xl mx-auto space-y-8">
      {/* Portada */}
      <section className="text-center">
        <h1 className="text-4xl font-bold">Thilma Navarro Ramírez</h1>
        <p className="text-xl text-gray-600 mt-2">
          Comunicación Estratégica | Cooperación Internacional | Innovación Tecnológica
        </p>
        <div className="mt-4 space-x-4">
          <a href="mailto:thilmajacobs@gmail.com" className="text-blue-600 hover:underline">
            thilmajacobs@gmail.com
          </a>
          <a
            href="https://www.linkedin.com/in/thilma-navarro"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center space-x-1 text-blue-600 hover:underline"
          >
            <Linkedin size={20} />
            <span>LinkedIn</span>
          </a>
        </div>
      </section>

      {/* Sobre mí */}
      <Card>
        <CardContent className="p-6">
          <h2 className="text-2xl font-semibold mb-4">Sobre mí</h2>
          <p>
            Comunicadora con enfoque estratégico y pasión por la transformación social a través de la tecnología. Experiencia en el desarrollo de estrategias 360°, comunicación para el desarrollo, cooperación internacional y gestión del conocimiento. Firme creyente en el poder del ciberfeminismo, la diplomacia científica y la innovación como motores del cambio.
          </p>
        </CardContent>
      </Card>

      {/* Competencias */}
      <Card>
        <CardContent className="p-6">
          <h2 className="text-2xl font-semibold mb-4">Competencias Clave</h2>
          <ul className="list-disc pl-6 space-y-1">
            <li>Comunicación estratégica 360°</li>
            <li>Gestión de proyectos de cooperación</li>
            <li>Redacción editorial y digital</li>
            <li>Relaciones públicas y alianzas</li>
            <li>Comunicación para el desarrollo y cambio social</li>
            <li>Producción de contenidos accesibles e inclusivos</li>
          </ul>
        </CardContent>
      </Card>

      {/* Proyectos destacados */}
      <Card>
        <CardContent className="p-6 space-y-4">
          <h2 className="text-2xl font-semibold mb-4">Proyectos Destacados</h2>
          <div>
            <h3 className="text-lg font-bold">Ciudadela Digital @Medellín</h3>
            <p>Relaciones corporativas para ampliar el acceso a cursos virtuales mediante alianzas público-privadas.</p>
          </div>
          <div>
            <h3 className="text-lg font-bold">Proyecto Podemos Ser – Fundación para la Reconciliación</h3>
            <p>Coordinación de comunicaciones y fidelización de participantes en Medellín.</p>
          </div>
          <div>
            <h3 className="text-lg font-bold">Tecnologías para Aprender – Mineros S.A.</h3>
            <p>Comunicación comunitaria para la apropiación tecnológica en zonas rurales del Bajo Cauca.</p>
          </div>
        </CardContent>
      </Card>

      {/* Educación */}
      <Card>
        <CardContent className="p-6">
          <h2 className="text-2xl font-semibold mb-4">Educación</h2>
          <ul className="list-disc pl-6 space-y-1">
            <li>Gestión de la Innovación Tecnológica – UPB</li>
            <li>Máster en Marketing Digital – Universidad Rey Juan Carlos</li>
            <li>Técnica en Diseño Gráfico Digital – CENSA</li>
            <li>Planeación de Proyectos de Cooperación – UdeA</li>
            <li>Comunicación y Relaciones Corporativas – Universidad de Medellín</li>
          </ul>
        </CardContent>
      </Card>

      {/* Contacto */}
      <section className="text-center py-8">
        <h2 className="text-2xl font-semibold mb-2">¿Conectamos?</h2>
        <p>Estoy disponible para proyectos, consultorías y colaboraciones.</p>
        <Button asChild className="mt-4">
          <a href="mailto:thilmajacobs@gmail.com">Contáctame</a>
        </Button>
      </section>
    </main>
  );
}